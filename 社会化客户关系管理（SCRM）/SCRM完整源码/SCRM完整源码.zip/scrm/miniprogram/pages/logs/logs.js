//logs.js

Page({
  data: {
    logs: []
  },
  onLoad: function () {
    
  }
})
