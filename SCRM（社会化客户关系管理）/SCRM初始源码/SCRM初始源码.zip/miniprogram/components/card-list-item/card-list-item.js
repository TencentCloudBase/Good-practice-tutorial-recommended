Component({
    properties:{
        userId:String
    },
    data:{
    },
    methods:{
    },
    ready() {
    }
})