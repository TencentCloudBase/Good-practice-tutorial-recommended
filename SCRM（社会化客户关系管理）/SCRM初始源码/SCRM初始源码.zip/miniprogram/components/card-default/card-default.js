Component({
    properties:{
        userInfo: Object
    },
    data:{
    },
    methods:{
    },
    ready() {
    }
})