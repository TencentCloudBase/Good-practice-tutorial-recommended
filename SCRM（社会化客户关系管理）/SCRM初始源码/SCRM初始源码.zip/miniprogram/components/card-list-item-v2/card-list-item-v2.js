Component({
    options: { 
        multipleSlots: true
    }, 
    properties:{
        user:Object
    },
    data:{
    },
    methods:{

    },
    ready() {
    }
})
